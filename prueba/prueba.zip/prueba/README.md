## Instructions to run
1. Navigate to folder */Prueba*
2. *NPM install*
3. *NPM run dev*
4. Navigate to localhost:8080

